// Message row click handler and filter functionality
document.addEventListener('DOMContentLoaded', function() {
    const messageRows = document.querySelectorAll('.message-row');
    const modal = document.getElementById('messageModal');
    const modalTimestamp = document.getElementById('modalTimestamp');
    const modalUnit = document.getElementById('modalUnit');
    const modalMessage = document.getElementById('modalMessage');

    // Filter elements
    const regionFilter = document.getElementById('regionFilter');
    const unitFilter = document.getElementById('unitFilter');
    const priorityFilter = document.getElementById('priorityFilter');
    const applyFiltersBtn = document.getElementById('applyFilters');

    // Add click event to each message row
    messageRows.forEach(row => {
        row.addEventListener('click', function() {
            const timestamp = this.querySelector('.message-timestamp').textContent;
            const unit = this.querySelector('.message-unit').textContent;
            const content = this.querySelector('.message-content').textContent;

            // Update modal content
            modalTimestamp.textContent = 'Timestamp: ' + timestamp;
            modalUnit.textContent = 'Unit: ' + unit;
            modalMessage.textContent = content;

            // Show modal
            modal.classList.add('active');
        });
    });

    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });

    // ESC key to close modal
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });

    // Filter functionality
    function applyFilters() {
        const selectedRegion = regionFilter.value.toLowerCase();
        const selectedUnit = unitFilter.value;
        const selectedPriority = priorityFilter.value;

        messageRows.forEach(row => {
            const messageContent = row.querySelector('.message-content').textContent.toLowerCase();
            const messageUnit = row.querySelector('.message-unit').textContent;
            const priorityClass = row.querySelector('.message-priority').className;

            let showRow = true;

            // Filter by region (check if message content contains region keyword)
            if (selectedRegion && !messageContent.includes(selectedRegion)) {
                showRow = false;
            }

            // Filter by unit
            if (selectedUnit && !messageUnit.includes(selectedUnit)) {
                showRow = false;
            }

            // Filter by priority
            if (selectedPriority) {
                if (!priorityClass.includes('priority-' + selectedPriority)) {
                    showRow = false;
                }
            }

            // Show or hide row
            if (showRow) {
                row.style.display = 'grid';
            } else {
                row.style.display = 'none';
            }
        });
    }

    // Apply filters on button click
    applyFiltersBtn.addEventListener('click', applyFilters);

    // Apply filters on select change (real-time filtering)
    regionFilter.addEventListener('change', applyFilters);
    unitFilter.addEventListener('change', applyFilters);
    priorityFilter.addEventListener('change', applyFilters);
});

// Close modal function
function closeModal() {
    const modal = document.getElementById('messageModal');
    modal.classList.remove('active');
}
