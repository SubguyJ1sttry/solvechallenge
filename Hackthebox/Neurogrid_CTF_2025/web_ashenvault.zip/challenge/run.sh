#!/bin/bash

# Build the Docker image
echo "Building Docker image..."
docker build -t ashenvault .

# Stop and remove any existing container with the same name
echo "Stopping and removing existing container (if any)..."
docker stop ashenvault-container 2>/dev/null || true
docker rm ashenvault-container 2>/dev/null || true

# Run the container
echo "Starting container..."
docker run -d \
  --name ashenvault-container \
  -p 80:80 \
  ashenvault

echo "Container started successfully!"
echo "Application is running at http://localhost"
echo ""
echo "To view logs: docker logs ashenvault-container"
echo "To stop: docker stop ashenvault-container"
echo "To remove: docker rm ashenvault-container"
